import { cursosMock, matchesMock, professoresMock } from '../mocks/matchProfessorCurso.mock';
import type {
  Curso,
  IndicadoresMatch,
  MatchProfessorCurso,
  NovaAssociacaoInput,
  Professor,
} from '../types/matchProfessorCurso.types';

// TODO: substituir por chamadas reais quando a API do módulo estiver disponível.
// A assinatura das funções já reflete o formato esperado da API (Promise + filtros server-side futuros).

let matches = [...matchesMock];

const STORAGE_KEY = 'efg-professores-curso-matches';

function carregarMatchesSalvos(): MatchProfessorCurso[] {
  if (typeof window === 'undefined') return [...matchesMock];

  try {
    const salvos = window.localStorage.getItem(STORAGE_KEY);
    return salvos ? JSON.parse(salvos) as MatchProfessorCurso[] : [...matchesMock];
  } catch {
    return [...matchesMock];
  }
}

function salvarMatches() {
  if (typeof window !== 'undefined') {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(matches));
  }
}

matches = carregarMatchesSalvos();

function delay<T>(valor: T): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(valor), 250));
}

export async function listarProfessores(): Promise<Professor[]> {
  return delay(professoresMock);
}

export async function listarCursos(): Promise<Curso[]> {
  return delay(cursosMock);
}

export async function listarMatches(): Promise<MatchProfessorCurso[]> {
  return delay(matches);
}

export async function obterIndicadores(): Promise<IndicadoresMatch> {
  const compatibilidadeAlta = matches.filter((m) => m.nivelCompatibilidade === 'alta').length;
  return delay({
    professoresCadastrados: professoresMock.length,
    cursosCadastrados: cursosMock.length,
    matchesRealizados: matches.length,
    compatibilidadeAlta,
  });
}

export async function criarAssociacao(input: NovaAssociacaoInput): Promise<MatchProfessorCurso> {
  const jaExiste = matches.some(
    (m) =>
      m.professorId === input.professorId &&
      m.cursoId === input.cursoId &&
      m.disciplina === input.disciplina
  );

  if (jaExiste) {
    throw new Error('Já existe uma associação para este professor, curso e disciplina.');
  }

  const professor = professoresMock.find((item) => item.id === input.professorId);
  const curso = cursosMock.find((item) => item.id === input.cursoId);

  if (!professor || !curso) {
    throw new Error('Professor ou curso não encontrado.');
  }

  const mesmaArea = professor.areaAtuacao === curso.area;
  const disponibilidadeInformada = input.disponibilidade.trim().length > 0;
  const criterios = {
    formacao: mesmaArea ? 90 : 55,
    experiencia: Math.min(100, 45 + professor.experienciaAnos * 5),
    areaAtuacao: mesmaArea ? 95 : 45,
    disponibilidade: disponibilidadeInformada ? 85 : 40,
  };
  const compatibilidade = Math.round(
    (criterios.formacao + criterios.experiencia + criterios.areaAtuacao + criterios.disponibilidade) / 4
  );
  const nivelCompatibilidade = compatibilidade >= 80 ? 'alta' : compatibilidade >= 55 ? 'media' : 'baixa';

  const novoMatch: MatchProfessorCurso = {
    id: `match-${Date.now()}`,
    professorId: input.professorId,
    cursoId: input.cursoId,
    disciplina: input.disciplina,
    compatibilidade,
    nivelCompatibilidade,
    criterios,
    justificativa: mesmaArea
      ? 'Associação criada manualmente com formação e área de atuação alinhadas ao curso.'
      : 'Associação criada manualmente; recomenda-se revisar a aderência da formação à área do curso.',
    status: 'disponivel',
    observacoes: input.observacoes,
  };

  matches = [novoMatch, ...matches];
  salvarMatches();
  return delay(novoMatch);
}

export async function excluirAssociacao(id: string): Promise<void> {
  matches = matches.filter((match) => match.id !== id);
  salvarMatches();
  return delay(undefined);
}
