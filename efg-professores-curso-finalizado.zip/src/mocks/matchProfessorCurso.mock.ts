import type { Curso, MatchProfessorCurso, Professor } from '../types/matchProfessorCurso.types';

export const professoresMock: Professor[] = [
  { id: 'prof-1', nome: 'Renata Aquino', formacao: 'Licenciatura em Matemática', experienciaAnos: 9, disponibilidade: 'Manhã e Tarde', areaAtuacao: 'Exatas' },
  { id: 'prof-2', nome: 'Thiago Bezerra', formacao: 'Bacharelado em Ciência da Computação', experienciaAnos: 5, disponibilidade: 'Tarde', areaAtuacao: 'Tecnologia' },
  { id: 'prof-3', nome: 'Camila Duarte', formacao: 'Licenciatura em Letras', experienciaAnos: 12, disponibilidade: 'Manhã', areaAtuacao: 'Linguagens' },
  { id: 'prof-4', nome: 'Eduardo Prado', formacao: 'Licenciatura em Física', experienciaAnos: 3, disponibilidade: 'Noite', areaAtuacao: 'Exatas' },
  { id: 'prof-5', nome: 'Juliana Matos', formacao: 'Licenciatura em Biologia', experienciaAnos: 7, disponibilidade: 'Manhã e Tarde', areaAtuacao: 'Biológicas' },
  { id: 'prof-6', nome: 'Rodrigo Nascimento', formacao: 'Bacharelado em Engenharia de Software', experienciaAnos: 4, disponibilidade: 'Tarde e Noite', areaAtuacao: 'Tecnologia' },
  { id: 'prof-7', nome: 'Patrícia Guedes', formacao: 'Licenciatura em História', experienciaAnos: 15, disponibilidade: 'Manhã', areaAtuacao: 'Humanas' },
  { id: 'prof-8', nome: 'Vinícius Camargo', formacao: 'Licenciatura em Educação Física', experienciaAnos: 6, disponibilidade: 'Tarde', areaAtuacao: 'Saúde e Bem-estar' },
];

export const cursosMock: Curso[] = [
  { id: 'curso-1', nome: 'Análise e Desenvolvimento de Sistemas', area: 'Tecnologia', disciplinas: ['Lógica de Programação', 'Banco de Dados', 'Algoritmos'] },
  { id: 'curso-2', nome: 'Matemática Aplicada', area: 'Exatas', disciplinas: ['Álgebra', 'Estatística', 'Cálculo I'] },
  { id: 'curso-3', nome: 'Letras', area: 'Linguagens', disciplinas: ['Redação', 'Literatura Brasileira', 'Gramática'] },
  { id: 'curso-4', nome: 'Ciências Biológicas', area: 'Biológicas', disciplinas: ['Biologia Celular', 'Ecologia'] },
  { id: 'curso-5', nome: 'História e Sociedade', area: 'Humanas', disciplinas: ['História do Brasil', 'Sociologia'] },
  { id: 'curso-6', nome: 'Educação Física Escolar', area: 'Saúde e Bem-estar', disciplinas: ['Esportes Coletivos', 'Saúde e Movimento'] },
];

export const matchesMock: MatchProfessorCurso[] = [
  { id: 'match-1', professorId: 'prof-1', cursoId: 'curso-2', disciplina: 'Cálculo I', compatibilidade: 92, nivelCompatibilidade: 'alta', criterios: { formacao: 95, experiencia: 90, areaAtuacao: 95, disponibilidade: 88 }, justificativa: 'Formação e área de atuação diretamente alinhadas à disciplina, com experiência consolidada.', status: 'disponivel' },
  { id: 'match-2', professorId: 'prof-2', cursoId: 'curso-1', disciplina: 'Lógica de Programação', compatibilidade: 88, nivelCompatibilidade: 'alta', criterios: { formacao: 92, experiencia: 78, areaAtuacao: 95, disponibilidade: 85 }, justificativa: 'Formação em Ciência da Computação cobre integralmente o conteúdo da disciplina.', status: 'alocado' },
  { id: 'match-3', professorId: 'prof-3', cursoId: 'curso-3', disciplina: 'Literatura Brasileira', compatibilidade: 95, nivelCompatibilidade: 'alta', criterios: { formacao: 98, experiencia: 96, areaAtuacao: 95, disponibilidade: 90 }, justificativa: 'Maior tempo de experiência do quadro na área de Linguagens.', status: 'disponivel' },
  { id: 'match-4', professorId: 'prof-4', cursoId: 'curso-2', disciplina: 'Estatística', compatibilidade: 61, nivelCompatibilidade: 'media', criterios: { formacao: 70, experiencia: 45, areaAtuacao: 75, disponibilidade: 55 }, justificativa: 'Boa aderência de área, mas experiência ainda em consolidação.', status: 'disponivel' },
  { id: 'match-5', professorId: 'prof-5', cursoId: 'curso-4', disciplina: 'Ecologia', compatibilidade: 90, nivelCompatibilidade: 'alta', criterios: { formacao: 94, experiencia: 88, areaAtuacao: 92, disponibilidade: 86 }, justificativa: 'Formação e experiência bem alinhadas ao conteúdo do curso.', status: 'alocado' },
  { id: 'match-6', professorId: 'prof-6', cursoId: 'curso-1', disciplina: 'Banco de Dados', compatibilidade: 79, nivelCompatibilidade: 'media', criterios: { formacao: 85, experiencia: 68, areaAtuacao: 88, disponibilidade: 76 }, justificativa: 'Boa base técnica, com espaço para ganho de experiência em sala.', status: 'disponivel' },
  { id: 'match-7', professorId: 'prof-7', cursoId: 'curso-5', disciplina: 'História do Brasil', compatibilidade: 97, nivelCompatibilidade: 'alta', criterios: { formacao: 98, experiencia: 98, areaAtuacao: 97, disponibilidade: 92 }, justificativa: 'Maior tempo de casa e especialização direta na disciplina.', status: 'disponivel' },
  { id: 'match-8', professorId: 'prof-8', cursoId: 'curso-6', disciplina: 'Esportes Coletivos', compatibilidade: 85, nivelCompatibilidade: 'alta', criterios: { formacao: 90, experiencia: 80, areaAtuacao: 90, disponibilidade: 80 }, justificativa: 'Formação específica e boa disponibilidade de horário.', status: 'indisponivel' },
  { id: 'match-9', professorId: 'prof-1', cursoId: 'curso-1', disciplina: 'Algoritmos', compatibilidade: 48, nivelCompatibilidade: 'baixa', criterios: { formacao: 40, experiencia: 55, areaAtuacao: 45, disponibilidade: 52 }, justificativa: 'Formação em Matemática dá suporte parcial, mas fora da área principal do curso.', status: 'disponivel' },
  { id: 'match-10', professorId: 'prof-3', cursoId: 'curso-3', disciplina: 'Redação', compatibilidade: 91, nivelCompatibilidade: 'alta', criterios: { formacao: 95, experiencia: 92, areaAtuacao: 90, disponibilidade: 88 }, justificativa: 'Perfil já atua na disciplina correlata com bons resultados.', status: 'alocado' },
  { id: 'match-11', professorId: 'prof-4', cursoId: 'curso-2', disciplina: 'Álgebra', compatibilidade: 58, nivelCompatibilidade: 'media', criterios: { formacao: 65, experiencia: 42, areaAtuacao: 70, disponibilidade: 50 }, justificativa: 'Disponibilidade noturna limita o encaixe na grade atual do curso.', status: 'indisponivel' },
  { id: 'match-12', professorId: 'prof-6', cursoId: 'curso-1', disciplina: 'Algoritmos', compatibilidade: 82, nivelCompatibilidade: 'alta', criterios: { formacao: 88, experiencia: 72, areaAtuacao: 90, disponibilidade: 78 }, justificativa: 'Boa aderência técnica com a proposta da disciplina.', status: 'disponivel' },
  { id: 'match-13', professorId: 'prof-5', cursoId: 'curso-4', disciplina: 'Biologia Celular', compatibilidade: 93, nivelCompatibilidade: 'alta', criterios: { formacao: 96, experiencia: 90, areaAtuacao: 94, disponibilidade: 90 }, justificativa: 'Especialização direta no conteúdo da disciplina.', status: 'disponivel' },
  { id: 'match-14', professorId: 'prof-7', cursoId: 'curso-5', disciplina: 'Sociologia', compatibilidade: 74, nivelCompatibilidade: 'media', criterios: { formacao: 80, experiencia: 82, areaAtuacao: 70, disponibilidade: 65 }, justificativa: 'Boa experiência geral, com formação complementar em Humanas.', status: 'disponivel' },
  { id: 'match-15', professorId: 'prof-2', cursoId: 'curso-1', disciplina: 'Banco de Dados', compatibilidade: 86, nivelCompatibilidade: 'alta', criterios: { formacao: 90, experiencia: 76, areaAtuacao: 92, disponibilidade: 84 }, justificativa: 'Formação técnica cobre integralmente os pré-requisitos da disciplina.', status: 'alocado' },
  { id: 'match-16', professorId: 'prof-8', cursoId: 'curso-6', disciplina: 'Saúde e Movimento', compatibilidade: 40, nivelCompatibilidade: 'baixa', criterios: { formacao: 45, experiencia: 38, areaAtuacao: 45, disponibilidade: 32 }, justificativa: 'Disponibilidade de horário conflita com a grade atual do curso.', status: 'indisponivel' },
];
