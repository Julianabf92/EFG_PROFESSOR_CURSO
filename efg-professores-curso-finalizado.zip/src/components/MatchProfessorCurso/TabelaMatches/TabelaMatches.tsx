import type { Curso, MatchProfessorCurso, Professor, StatusDisponibilidade } from '../../../types/matchProfessorCurso.types';
import { CompatibilidadeBadge } from '../CompatibilidadeBadge/CompatibilidadeBadge';
import styles from './TabelaMatches.module.css';

const STATUS_LABEL: Record<StatusDisponibilidade, string> = {
  disponivel: 'Disponível',
  alocado: 'Alocado',
  indisponivel: 'Indisponível',
};

const STATUS_TONE: Record<StatusDisponibilidade, string> = {
  disponivel: 'success',
  alocado: 'info',
  indisponivel: 'danger',
};

interface TabelaMatchesProps {
  matches: MatchProfessorCurso[];
  professoresPorId: Map<string, Professor>;
  cursosPorId: Map<string, Curso>;
  carregando: boolean;
  paginaAtual: number;
  totalPaginas: number;
  onIrParaPagina: (pagina: number) => void;
  onVisualizar: (match: MatchProfessorCurso) => void;
}

export function TabelaMatches({
  matches,
  professoresPorId,
  cursosPorId,
  carregando,
  paginaAtual,
  totalPaginas,
  onIrParaPagina,
  onVisualizar,
}: TabelaMatchesProps) {
  if (carregando) {
    return <div className={styles.estado}>Carregando matches…</div>;
  }

  if (matches.length === 0) {
    return (
      <div className={styles.estado}>
        <p className={styles.estadoTitulo}>Nenhum resultado encontrado</p>
        <p className={styles.estadoTexto}>Ajuste os filtros ou limpe a busca para ver outros matches.</p>
      </div>
    );
  }

  return (
    <>
      <div className={styles.tableWrapper}>
        <table>
          <thead>
            <tr>
              <th>Professor</th>
              <th>Curso</th>
              <th>Área</th>
              <th>Compatibilidade</th>
              <th>Status</th>
              <th className={styles.acoesHeader}>Ações</th>
            </tr>
          </thead>
          <tbody>
            {matches.map((match) => {
              const professor = professoresPorId.get(match.professorId);
              const curso = cursosPorId.get(match.cursoId);
              if (!professor || !curso) return null;

              return (
                <tr key={match.id}>
                  <td data-label="Professor">{professor.nome}</td>
                  <td data-label="Curso">{curso.nome}</td>
                  <td data-label="Área">{curso.area}</td>
                  <td data-label="Compatibilidade">
                    <CompatibilidadeBadge percentual={match.compatibilidade} nivel={match.nivelCompatibilidade} />
                  </td>
                  <td data-label="Status">
                    <span className={`${styles.badge} ${styles[STATUS_TONE[match.status]]}`}>
                      {STATUS_LABEL[match.status]}
                    </span>
                  </td>
                  <td className={styles.acoes}>
                    <button type="button" className={styles.botaoVisualizar} onClick={() => onVisualizar(match)}>
                      Visualizar
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {totalPaginas > 1 && (
        <div className={styles.paginacao}>
          <button
            type="button"
            disabled={paginaAtual === 1}
            onClick={() => onIrParaPagina(paginaAtual - 1)}
          >
            Anterior
          </button>
          <span>Página {paginaAtual} de {totalPaginas}</span>
          <button
            type="button"
            disabled={paginaAtual === totalPaginas}
            onClick={() => onIrParaPagina(paginaAtual + 1)}
          >
            Próxima
          </button>
        </div>
      )}
    </>
  );
}
