import { zodResolver } from '@hookform/resolvers/zod';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import type { Curso, Professor } from '../../../types/matchProfessorCurso.types';
import { Drawer } from '../shared/Drawer';
import { formAssociacaoSchema, type FormAssociacaoValues } from './FormAssociacao.schema';
import styles from './FormAssociacao.module.css';

interface FormAssociacaoProps {
  aberto: boolean;
  professores: Professor[];
  cursos: Curso[];
  existeAssociacao: (professorId: string, cursoId: string, disciplina: string) => boolean;
  onSalvar: (valores: FormAssociacaoValues) => Promise<void>;
  onFechar: () => void;
}

export function FormAssociacao({
  aberto,
  professores,
  cursos,
  existeAssociacao,
  onSalvar,
  onFechar,
}: FormAssociacaoProps) {
  const [erroSubmit, setErroSubmit] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors, isDirty, isSubmitting },
  } = useForm<FormAssociacaoValues>({
    resolver: zodResolver(formAssociacaoSchema),
    defaultValues: { professorId: '', cursoId: '', disciplina: '', disponibilidade: '', observacoes: '' },
  });

  const cursoIdSelecionado = watch('cursoId');
  const cursoSelecionado = cursos.find((c) => c.id === cursoIdSelecionado);

  function fecharComConfirmacao() {
    if (isDirty && !window.confirm('Existem alterações não salvas. Deseja realmente sair sem salvar?')) {
      return;
    }
    reset();
    setErroSubmit(null);
    onFechar();
  }

  async function onSubmit(valores: FormAssociacaoValues) {
    setErroSubmit(null);

    if (existeAssociacao(valores.professorId, valores.cursoId, valores.disciplina)) {
      setErroSubmit('Já existe uma associação para este professor, curso e disciplina.');
      return;
    }

    try {
      await onSalvar(valores);
      reset();
    } catch {
      setErroSubmit('Não foi possível salvar a associação. Tente novamente.');
    }
  }

  return (
    <Drawer
      aberto={aberto}
      titulo="Associar Professor a Curso"
      subtitulo="Preencha os dados para criar uma nova associação."
      onFechar={fecharComConfirmacao}
    >
      <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
        {erroSubmit && <div className={styles.erroSubmit}>{erroSubmit}</div>}

        <div className={styles.campo}>
          <label htmlFor="professorId">Professor</label>
          <select id="professorId" {...register('professorId')}>
            <option value="">Selecione um professor</option>
            {professores.map((p) => (
              <option key={p.id} value={p.id}>{p.nome}</option>
            ))}
          </select>
          {errors.professorId && <span className={styles.erroCampo}>{errors.professorId.message}</span>}
        </div>

        <div className={styles.campo}>
          <label htmlFor="cursoId">Curso</label>
          <select id="cursoId" {...register('cursoId')}>
            <option value="">Selecione um curso</option>
            {cursos.map((c) => (
              <option key={c.id} value={c.id}>{c.nome}</option>
            ))}
          </select>
          {errors.cursoId && <span className={styles.erroCampo}>{errors.cursoId.message}</span>}
        </div>

        <div className={styles.campo}>
          <label htmlFor="disciplina">Disciplina</label>
          <select id="disciplina" disabled={!cursoSelecionado} {...register('disciplina')}>
            <option value="">{cursoSelecionado ? 'Selecione uma disciplina' : 'Selecione um curso primeiro'}</option>
            {cursoSelecionado?.disciplinas.map((disciplina) => (
              <option key={disciplina} value={disciplina}>{disciplina}</option>
            ))}
          </select>
          {errors.disciplina && <span className={styles.erroCampo}>{errors.disciplina.message}</span>}
        </div>

        <div className={styles.campo}>
          <label htmlFor="disponibilidade">Disponibilidade</label>
          <input id="disponibilidade" placeholder="Ex.: Manhã e Tarde" {...register('disponibilidade')} />
          {errors.disponibilidade && <span className={styles.erroCampo}>{errors.disponibilidade.message}</span>}
        </div>

        <div className={styles.campo}>
          <label htmlFor="observacoes">Observações</label>
          <textarea id="observacoes" rows={3} {...register('observacoes')} />
        </div>

        <div className={styles.acoes}>
          <button type="button" className={styles.cancelar} onClick={fecharComConfirmacao}>
            Cancelar
          </button>
          <button type="submit" className={styles.salvar} disabled={isSubmitting}>
            {isSubmitting ? 'Salvando…' : 'Salvar associação'}
          </button>
        </div>
      </form>
    </Drawer>
  );
}
