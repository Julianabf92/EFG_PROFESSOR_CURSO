import { z } from 'zod';

export const formAssociacaoSchema = z.object({
  professorId: z.string().min(1, 'Selecione um professor.'),
  cursoId: z.string().min(1, 'Selecione um curso.'),
  disciplina: z.string().min(1, 'Selecione uma disciplina.'),
  disponibilidade: z.string().min(1, 'Informe a disponibilidade.'),
  observacoes: z.string().optional(),
});

export type FormAssociacaoValues = z.infer<typeof formAssociacaoSchema>;
