import type { Curso, MatchProfessorCurso, Professor } from '../../../types/matchProfessorCurso.types';
import { CompatibilidadeBadge } from '../CompatibilidadeBadge/CompatibilidadeBadge';
import { Drawer } from '../shared/Drawer';
import styles from './DetalhesMatchDrawer.module.css';

interface DetalhesMatchDrawerProps {
  match: MatchProfessorCurso | null;
  professor: Professor | null;
  curso: Curso | null;
  onFechar: () => void;
  onExcluir: (id: string) => Promise<void>;
}

const CRITERIOS_LABEL: Record<keyof MatchProfessorCurso['criterios'], string> = {
  formacao: 'Formação',
  experiencia: 'Experiência',
  areaAtuacao: 'Área de atuação',
  disponibilidade: 'Disponibilidade',
};

export function DetalhesMatchDrawer({ match, professor, curso, onFechar, onExcluir }: DetalhesMatchDrawerProps) {
  const aberto = Boolean(match && professor && curso);

  return (
    <Drawer aberto={aberto} titulo="Detalhes do match" subtitulo={professor?.nome} onFechar={onFechar}>
      {match && professor && curso && (
        <>
          <section className={styles.secao}>
            <h3 className={styles.secaoTitulo}>Professor</h3>
            <dl className={styles.lista}>
              <div><dt>Nome</dt><dd>{professor.nome}</dd></div>
              <div><dt>Formação</dt><dd>{professor.formacao}</dd></div>
              <div><dt>Experiência</dt><dd>{professor.experienciaAnos} anos</dd></div>
              <div><dt>Disponibilidade</dt><dd>{professor.disponibilidade}</dd></div>
            </dl>
          </section>

          <section className={styles.secao}>
            <h3 className={styles.secaoTitulo}>Curso</h3>
            <dl className={styles.lista}>
              <div><dt>Nome</dt><dd>{curso.nome}</dd></div>
              <div><dt>Área</dt><dd>{curso.area}</dd></div>
              <div><dt>Disciplinas</dt><dd>{curso.disciplinas.join(', ')}</dd></div>
            </dl>
          </section>

          <section className={styles.secao}>
            <div className={styles.compatibilidadeTopo}>
              <h3 className={styles.secaoTitulo}>Compatibilidade</h3>
              <CompatibilidadeBadge percentual={match.compatibilidade} nivel={match.nivelCompatibilidade} />
            </div>

            <div className={styles.criterios}>
              {(Object.keys(match.criterios) as Array<keyof MatchProfessorCurso['criterios']>).map((chave) => (
                <div key={chave} className={styles.criterio}>
                  <div className={styles.criterioTopo}>
                    <span>{CRITERIOS_LABEL[chave]}</span>
                    <span>{match.criterios[chave]}%</span>
                  </div>
                  <div className={styles.barra}>
                    <div className={styles.barraPreenchida} style={{ width: `${match.criterios[chave]}%` }} />
                  </div>
                </div>
              ))}
            </div>

            <p className={styles.justificativa}>{match.justificativa}</p>
          </section>

          <button
            type="button"
            className={styles.excluir}
            onClick={() => {
              if (window.confirm('Deseja remover esta associação?')) void onExcluir(match.id);
            }}
          >
            Remover associação
          </button>
        </>
      )}
    </Drawer>
  );
}
