import type { IndicadoresMatch } from '../../../types/matchProfessorCurso.types';
import styles from './IndicadoresResumo.module.css';

interface IndicadoresResumoProps {
  indicadores: IndicadoresMatch;
}

export function IndicadoresResumo({ indicadores }: IndicadoresResumoProps) {
  const itens = [
    { label: 'Professores cadastrados', valor: indicadores.professoresCadastrados },
    { label: 'Cursos cadastrados', valor: indicadores.cursosCadastrados },
    { label: 'Matches realizados', valor: indicadores.matchesRealizados },
    { label: 'Compatibilidade alta', valor: indicadores.compatibilidadeAlta },
  ];

  return (
    <div className={styles.grid}>
      {itens.map((item) => (
        <div key={item.label} className={styles.card}>
          <span className={styles.label}>{item.label}</span>
          <p className={styles.valor}>{item.valor}</p>
        </div>
      ))}
    </div>
  );
}
