import type { Curso, FiltrosMatch as FiltrosMatchType } from '../../../types/matchProfessorCurso.types';
import styles from './FiltrosMatch.module.css';

interface FiltrosMatchProps {
  filtros: FiltrosMatchType;
  cursos: Curso[];
  areas: string[];
  onAlterar: (filtros: Partial<FiltrosMatchType>) => void;
  onLimpar: () => void;
}

export function FiltrosMatch({ filtros, cursos, areas, onAlterar, onLimpar }: FiltrosMatchProps) {
  return (
    <div className={styles.card}>
      <div className={styles.buscaRow}>
        <div className={styles.searchInput}>
          🔍
          <input
            placeholder="Buscar por professor ou curso…"
            value={filtros.busca}
            onChange={(e) => onAlterar({ busca: e.target.value })}
          />
        </div>
        <button type="button" className={styles.limpar} onClick={onLimpar}>
          Limpar filtros
        </button>
      </div>

      <div className={styles.selects}>
        <label className={styles.campo}>
          <span>Curso</span>
          <select value={filtros.cursoId} onChange={(e) => onAlterar({ cursoId: e.target.value })}>
            <option value="todos">Todos</option>
            {cursos.map((curso) => (
              <option key={curso.id} value={curso.id}>{curso.nome}</option>
            ))}
          </select>
        </label>

        <label className={styles.campo}>
          <span>Área de conhecimento</span>
          <select value={filtros.area} onChange={(e) => onAlterar({ area: e.target.value })}>
            <option value="todas">Todas</option>
            {areas.map((area) => (
              <option key={area} value={area}>{area}</option>
            ))}
          </select>
        </label>

        <label className={styles.campo}>
          <span>Compatibilidade</span>
          <select
            value={filtros.compatibilidade}
            onChange={(e) => onAlterar({ compatibilidade: e.target.value as FiltrosMatchType['compatibilidade'] })}
          >
            <option value="todas">Todas</option>
            <option value="alta">Alta</option>
            <option value="media">Média</option>
            <option value="baixa">Baixa</option>
          </select>
        </label>

        <label className={styles.campo}>
          <span>Status</span>
          <select
            value={filtros.status}
            onChange={(e) => onAlterar({ status: e.target.value as FiltrosMatchType['status'] })}
          >
            <option value="todos">Todos</option>
            <option value="disponivel">Disponível</option>
            <option value="alocado">Alocado</option>
            <option value="indisponivel">Indisponível</option>
          </select>
        </label>
      </div>
    </div>
  );
}
