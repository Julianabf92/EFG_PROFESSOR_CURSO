import type { NivelCompatibilidade } from '../../../types/matchProfessorCurso.types';
import styles from './CompatibilidadeBadge.module.css';

const NIVEL_LABEL: Record<NivelCompatibilidade, string> = {
  alta: 'Alta',
  media: 'Média',
  baixa: 'Baixa',
};

interface CompatibilidadeBadgeProps {
  percentual: number;
  nivel: NivelCompatibilidade;
}

export function CompatibilidadeBadge({ percentual, nivel }: CompatibilidadeBadgeProps) {
  return (
    <span className={`${styles.badge} ${styles[nivel]}`}>
      {percentual}% — {NIVEL_LABEL[nivel]}
    </span>
  );
}
