import { useEffect, useId, useRef } from 'react';
import styles from './Drawer.module.css';

interface DrawerProps {
  aberto: boolean;
  titulo: string;
  subtitulo?: string;
  onFechar: () => void;
  children: React.ReactNode;
}

export function Drawer({ aberto, titulo, subtitulo, onFechar, children }: DrawerProps) {
  const tituloId = useId();
  const botaoFecharRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!aberto) return;
    const overflowAnterior = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    botaoFecharRef.current?.focus();
    function handleEsc(e: KeyboardEvent) {
      if (e.key === 'Escape') onFechar();
    }
    document.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = overflowAnterior;
    };
  }, [aberto, onFechar]);

  if (!aberto) return null;

  return (
    <div className={styles.overlay} onMouseDown={onFechar}>
      <aside
        className={styles.panel}
        role="dialog"
        aria-modal="true"
        aria-labelledby={tituloId}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <header className={styles.header}>
          <div>
            <h2 id={tituloId} className={styles.titulo}>{titulo}</h2>
            {subtitulo && <p className={styles.subtitulo}>{subtitulo}</p>}
          </div>
          <button ref={botaoFecharRef} type="button" className={styles.fechar} onClick={onFechar} aria-label="Fechar painel">
            ✕
          </button>
        </header>
        <div className={styles.conteudo}>{children}</div>
      </aside>
    </div>
  );
}
