import { MatchProfessorCursoPage } from './pages/MatchProfessorCurso';

export function App() {
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="sidebar__brand">
          <span className="sidebar__brand-mark">EFG</span>
          <div className="sidebar__brand-text">
            <b>EFG</b>
            <span>Gestão Interna</span>
          </div>
        </div>
        <nav className="sidebar__nav">
          <div className="sidebar__item">Dashboard</div>
          <div className="sidebar__item">Cantina</div>
          <div className="sidebar__item">Laboratórios</div>
          <div className="sidebar__item">Busca Ativa</div>
          <div className="sidebar__item active">Professores × Curso</div>
          <div className="sidebar__item">Conflitos</div>
          <div className="sidebar__item">Estacionamento</div>
        </nav>
      </aside>
      <div className="main">
        <header className="header">
          <b>Preview isolado do módulo — shell ao lado é só contexto visual, não faz parte da entrega</b>
        </header>
        <main className="content">
          <MatchProfessorCursoPage />
        </main>
      </div>
    </div>
  );
}
