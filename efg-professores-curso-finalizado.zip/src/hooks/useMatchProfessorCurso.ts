import { useEffect, useMemo, useState } from 'react';
import {
  criarAssociacao,
  excluirAssociacao,
  listarCursos,
  listarMatches,
  listarProfessores,
  obterIndicadores,
} from '../services/matchProfessorCurso.service';
import type {
  Curso,
  FiltrosMatch,
  IndicadoresMatch,
  MatchProfessorCurso,
  NovaAssociacaoInput,
  Professor,
} from '../types/matchProfessorCurso.types';

const ITENS_POR_PAGINA = 8;

const filtrosIniciais: FiltrosMatch = {
  busca: '',
  cursoId: 'todos',
  area: 'todas',
  compatibilidade: 'todas',
  status: 'todos',
};

export function useMatchProfessorCurso() {
  const [professores, setProfessores] = useState<Professor[]>([]);
  const [cursos, setCursos] = useState<Curso[]>([]);
  const [matches, setMatches] = useState<MatchProfessorCurso[]>([]);
  const [indicadores, setIndicadores] = useState<IndicadoresMatch | null>(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  const [filtros, setFiltros] = useState<FiltrosMatch>(filtrosIniciais);
  const [pagina, setPagina] = useState(1);

  const [matchSelecionado, setMatchSelecionado] = useState<MatchProfessorCurso | null>(null);
  const [formularioAberto, setFormularioAberto] = useState(false);
  const [mensagem, setMensagem] = useState<string | null>(null);

  async function carregarDados() {
    setCarregando(true);
    setErro(null);
    try {
      const [profs, cursosResp, matchesResp, indicadoresResp] = await Promise.all([
        listarProfessores(),
        listarCursos(),
        listarMatches(),
        obterIndicadores(),
      ]);
      setProfessores(profs);
      setCursos(cursosResp);
      setMatches(matchesResp);
      setIndicadores(indicadoresResp);
    } catch {
      setErro('Não foi possível carregar os dados do módulo. Tente novamente.');
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    carregarDados();
  }, []);

  const professoresPorId = useMemo(
    () => new Map(professores.map((p) => [p.id, p])),
    [professores]
  );
  const cursosPorId = useMemo(() => new Map(cursos.map((c) => [c.id, c])), [cursos]);

  const areasDisponiveis = useMemo(
    () => Array.from(new Set(cursos.map((c) => c.area))),
    [cursos]
  );

  const matchesFiltrados = useMemo(() => {
    const busca = filtros.busca.trim().toLowerCase();

    return matches.filter((match) => {
      const professor = professoresPorId.get(match.professorId);
      const curso = cursosPorId.get(match.cursoId);
      if (!professor || !curso) return false;

      const combinaBusca =
        !busca ||
        professor.nome.toLowerCase().includes(busca) ||
        curso.nome.toLowerCase().includes(busca);

      const combinaCurso = filtros.cursoId === 'todos' || match.cursoId === filtros.cursoId;
      const combinaArea = filtros.area === 'todas' || curso.area === filtros.area;
      const combinaCompatibilidade =
        filtros.compatibilidade === 'todas' || match.nivelCompatibilidade === filtros.compatibilidade;
      const combinaStatus = filtros.status === 'todos' || match.status === filtros.status;

      return combinaBusca && combinaCurso && combinaArea && combinaCompatibilidade && combinaStatus;
    });
  }, [matches, filtros, professoresPorId, cursosPorId]);

  const totalPaginas = Math.max(1, Math.ceil(matchesFiltrados.length / ITENS_POR_PAGINA));
  const paginaAtual = Math.min(pagina, totalPaginas);
  const matchesPaginados = matchesFiltrados.slice(
    (paginaAtual - 1) * ITENS_POR_PAGINA,
    paginaAtual * ITENS_POR_PAGINA
  );

  function atualizarFiltros(novosFiltros: Partial<FiltrosMatch>) {
    setFiltros((atual) => ({ ...atual, ...novosFiltros }));
    setPagina(1);
  }

  function limparFiltros() {
    setFiltros(filtrosIniciais);
    setPagina(1);
  }

  function abrirDetalhes(match: MatchProfessorCurso) {
    setMatchSelecionado(match);
  }

  function fecharDetalhes() {
    setMatchSelecionado(null);
  }

  function abrirFormulario() {
    setFormularioAberto(true);
  }

  function fecharFormulario() {
    setFormularioAberto(false);
  }

  async function associarProfessorCurso(input: NovaAssociacaoInput) {
    await criarAssociacao(input);
    await carregarDados();
    setFormularioAberto(false);
    setMensagem('Associação criada com sucesso.');
  }

  async function removerAssociacao(id: string) {
    await excluirAssociacao(id);
    setMatchSelecionado(null);
    await carregarDados();
    setMensagem('Associação removida com sucesso.');
  }

  function existeAssociacao(professorId: string, cursoId: string, disciplina: string) {
    return matches.some(
      (m) => m.professorId === professorId && m.cursoId === cursoId && m.disciplina === disciplina
    );
  }

  return {
    professores,
    cursos,
    professoresPorId,
    cursosPorId,
    areasDisponiveis,
    indicadores,
    carregando,
    erro,
    filtros,
    atualizarFiltros,
    limparFiltros,
    matchesFiltrados,
    matchesPaginados,
    paginaAtual,
    totalPaginas,
    irParaPagina: setPagina,
    matchSelecionado,
    abrirDetalhes,
    fecharDetalhes,
    formularioAberto,
    abrirFormulario,
    fecharFormulario,
    associarProfessorCurso,
    removerAssociacao,
    existeAssociacao,
    mensagem,
    fecharMensagem: () => setMensagem(null),
    recarregar: carregarDados,
  };
}
