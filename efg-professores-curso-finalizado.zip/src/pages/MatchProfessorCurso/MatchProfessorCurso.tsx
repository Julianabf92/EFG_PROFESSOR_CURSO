import { DetalhesMatchDrawer } from '../../components/MatchProfessorCurso/DetalhesMatchDrawer/DetalhesMatchDrawer';
import { FiltrosMatch } from '../../components/MatchProfessorCurso/FiltrosMatch/FiltrosMatch';
import { FormAssociacao } from '../../components/MatchProfessorCurso/FormAssociacao/FormAssociacao';
import { IndicadoresResumo } from '../../components/MatchProfessorCurso/IndicadoresResumo/IndicadoresResumo';
import { TabelaMatches } from '../../components/MatchProfessorCurso/TabelaMatches/TabelaMatches';
import { useMatchProfessorCurso } from '../../hooks/useMatchProfessorCurso';
import styles from './MatchProfessorCurso.module.css';

export function MatchProfessorCursoPage() {
  const {
    professores,
    cursos,
    professoresPorId,
    cursosPorId,
    areasDisponiveis,
    indicadores,
    carregando,
    erro,
    filtros,
    atualizarFiltros,
    limparFiltros,
    matchesPaginados,
    paginaAtual,
    totalPaginas,
    irParaPagina,
    matchSelecionado,
    abrirDetalhes,
    fecharDetalhes,
    formularioAberto,
    abrirFormulario,
    fecharFormulario,
    associarProfessorCurso,
    removerAssociacao,
    existeAssociacao,
    recarregar,
    mensagem,
    fecharMensagem,
  } = useMatchProfessorCurso();

  const professorSelecionado = matchSelecionado ? professoresPorId.get(matchSelecionado.professorId) ?? null : null;
  const cursoSelecionado = matchSelecionado ? cursosPorId.get(matchSelecionado.cursoId) ?? null : null;

  return (
    <div className={styles.pagina}>
      <div className={styles.cabecalho}>
        <div>
          <h1 className={styles.titulo}>Professores × Curso</h1>
          <p className={styles.subtitulo}>Gerencie a compatibilidade entre professores e cursos da EFG.</p>
        </div>
        <div className={styles.acoes}>
          <button type="button" className={styles.botaoSecundario} onClick={recarregar}>
            Atualizar
          </button>
          <button type="button" className={styles.botaoPrimario} onClick={abrirFormulario}>
            + Adicionar associação
          </button>
        </div>
      </div>

      {erro && <div className={styles.alerta}>{erro}</div>}
      {mensagem && (
        <div className={styles.sucesso} role="status">
          <span>{mensagem}</span>
          <button type="button" onClick={fecharMensagem} aria-label="Fechar mensagem">✕</button>
        </div>
      )}

      {indicadores && <IndicadoresResumo indicadores={indicadores} />}

      <FiltrosMatch
        filtros={filtros}
        cursos={cursos}
        areas={areasDisponiveis}
        onAlterar={atualizarFiltros}
        onLimpar={limparFiltros}
      />

      <TabelaMatches
        matches={matchesPaginados}
        professoresPorId={professoresPorId}
        cursosPorId={cursosPorId}
        carregando={carregando}
        paginaAtual={paginaAtual}
        totalPaginas={totalPaginas}
        onIrParaPagina={irParaPagina}
        onVisualizar={abrirDetalhes}
      />

      <DetalhesMatchDrawer
        match={matchSelecionado}
        professor={professorSelecionado}
        curso={cursoSelecionado}
        onFechar={fecharDetalhes}
        onExcluir={removerAssociacao}
      />

      <FormAssociacao
        aberto={formularioAberto}
        professores={professores}
        cursos={cursos}
        existeAssociacao={existeAssociacao}
        onSalvar={associarProfessorCurso}
        onFechar={fecharFormulario}
      />
    </div>
  );
}
