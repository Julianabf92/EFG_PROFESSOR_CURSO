export { MatchProfessorCursoPage } from './MatchProfessorCurso';
