export type NivelCompatibilidade = 'alta' | 'media' | 'baixa';

export type StatusDisponibilidade = 'disponivel' | 'alocado' | 'indisponivel';

export interface Professor {
  id: string;
  nome: string;
  formacao: string;
  experienciaAnos: number;
  disponibilidade: string;
  areaAtuacao: string;
}

export interface Curso {
  id: string;
  nome: string;
  area: string;
  disciplinas: string[];
}

export interface CriteriosCompatibilidade {
  formacao: number;
  experiencia: number;
  areaAtuacao: number;
  disponibilidade: number;
}

export interface MatchProfessorCurso {
  id: string;
  professorId: string;
  cursoId: string;
  disciplina: string;
  compatibilidade: number;
  nivelCompatibilidade: NivelCompatibilidade;
  criterios: CriteriosCompatibilidade;
  justificativa: string;
  status: StatusDisponibilidade;
  observacoes?: string;
}

export interface FiltrosMatch {
  busca: string;
  cursoId: string;
  area: string;
  compatibilidade: NivelCompatibilidade | 'todas';
  status: StatusDisponibilidade | 'todos';
}

export interface NovaAssociacaoInput {
  professorId: string;
  cursoId: string;
  disciplina: string;
  disponibilidade: string;
  observacoes?: string;
}

export interface IndicadoresMatch {
  professoresCadastrados: number;
  cursosCadastrados: number;
  matchesRealizados: number;
  compatibilidadeAlta: number;
}
