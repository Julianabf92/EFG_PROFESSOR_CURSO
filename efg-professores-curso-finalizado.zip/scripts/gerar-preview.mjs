import { readFile, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const dist = join(process.cwd(), 'dist');
const assets = join(dist, 'assets');
const arquivos = await readdir(assets);
const css = await readFile(join(assets, arquivos.find((arquivo) => arquivo.endsWith('.css'))), 'utf8');
const javascript = await readFile(join(assets, arquivos.find((arquivo) => arquivo.endsWith('.js'))), 'utf8');

const html = `<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Preview do módulo Professores por Curso da EFG" />
    <title>EFG | Professores × Curso</title>
    <style>${css}</style>
  </head>
  <body>
    <div id="root"></div>
    <script type="module">${javascript}</script>
  </body>
</html>`;

await writeFile(join(dist, 'EFG-Professores-Curso-Preview.html'), html, 'utf8');
console.log('Preview único criado em dist/EFG-Professores-Curso-Preview.html');
