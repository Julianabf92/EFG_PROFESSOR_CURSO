# Preview — Módulo Professores × Curso (EFG)

Este projeto é só um **preview isolado e executável** do módulo, pra você visualizar
o resultado no navegador antes de integrar ao repositório real do sistema.
O "shell" (barra lateral/cabeçalho) que envolve o módulo é decorativo, só pra dar
contexto visual — não faz parte da entrega do módulo em si.

Os arquivos que realmente compõem a entrega estão em:

```
src/types/
src/mocks/
src/services/
src/hooks/
src/pages/MatchProfessorCurso/
src/components/MatchProfessorCurso/
```

## Como rodar

### Opção mais fácil — sem instalar nada

Abra a pasta `dist` e dê dois cliques em `EFG-Professores-Curso-Preview.html`.
O módulo abrirá pronto no navegador.

### Opção para desenvolvimento

1. Abra esta pasta no VS Code.
2. Abra um terminal (Ctrl+` ou Terminal → New Terminal).
3. Rode:

```bash
npm install
npm run dev
```

4. O terminal vai mostrar um endereço, geralmente `http://localhost:5173`.
   Abra esse link no navegador (ou Ctrl+clique em cima dele no terminal).

Qualquer alteração que você fizer nos arquivos `.tsx`/`.css` atualiza a tela
sozinha (hot reload), sem precisar recarregar a página manualmente.

## Requisito

Node.js instalado (versão 18 ou superior). Pra checar: `node -v` no terminal.

## Funcionalidades concluídas

- indicadores gerais e atualização dos dados;
- busca e filtros combinados;
- paginação e visualização detalhada da compatibilidade;
- criação de associação com validação e cálculo inicial de compatibilidade;
- prevenção de associações duplicadas;
- exclusão de associação com confirmação;
- persistência local das alterações no navegador;
- layout responsivo para computador, tablet e celular.

> Neste preview os dados ficam salvos no navegador (`localStorage`). Na integração
> com o sistema principal, substitua o serviço mock pelas rotas da API.
